// routes/auth.js - Authentication Routes (Fixed)
const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const { body, validationResult } = require('express-validator');
const { db, auditLog, logSecurityEvent } = require('../db/database');
const { generateTokens, verifyToken } = require('../middleware/auth');
const { authLimiter } = require('../middleware/security');

// POST /api/auth/login
router.post('/login', authLimiter, [
  body('username').trim().notEmpty().isLength({ min: 3, max: 50 }).escape(),
  body('password').notEmpty().isLength({ min: 6, max: 100 })
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, message: 'اطلاعات وارد شده نامعتبر است' });
  }

  const { username, password } = req.body;
  const ip = req.ip;
  const ua = req.headers['user-agent'];

  try {
    const user = db.prepare('SELECT * FROM users WHERE username = ? AND is_active = 1').get(username);

    if (!user) {
      logSecurityEvent('login_failed_user_not_found', ip, ua, { username }, 'medium');
      // Generic message to avoid username enumeration
      return res.status(401).json({ success: false, message: 'نام کاربری یا رمز عبور اشتباه است' });
    }

    // Check if locked
    if (user.locked_until && new Date(user.locked_until) > new Date()) {
      const remaining = Math.ceil((new Date(user.locked_until) - new Date()) / 60000);
      logSecurityEvent('login_locked_account', ip, ua, { username }, 'high');
      return res.status(429).json({
        success: false,
        message: `حساب کاربری موقتاً قفل شده است. ${remaining} دقیقه صبر کنید.`
      });
    }

    const isValid = await bcrypt.compare(password, user.password);

    if (!isValid) {
      const attempts = (user.login_attempts || 0) + 1;
      const lockData = {};

      if (attempts >= 5) {
        lockData.locked_until = new Date(Date.now() + 30 * 60 * 1000).toISOString();
        logSecurityEvent('account_locked', ip, ua, { username, attempts }, 'high');
      }

      db.prepare('UPDATE users SET login_attempts = ?, locked_until = ? WHERE id = ?')
        .run(attempts, lockData.locked_until || null, user.id);

      logSecurityEvent('login_failed_wrong_password', ip, ua, { username, attempts }, 'medium');

      const remaining = 5 - attempts;
      return res.status(401).json({
        success: false,
        message: attempts >= 5
          ? 'حساب شما به مدت ۳۰ دقیقه قفل شد.'
          : `رمز عبور اشتباه است. ${remaining} تلاش باقی مانده.`
      });
    }

    // Success - reset attempts and update last login
    db.prepare(`UPDATE users SET login_attempts = 0, locked_until = NULL, last_login = datetime('now') WHERE id = ?`)
      .run(user.id);

    const { accessToken } = generateTokens(user);
    auditLog(user.id, 'login', 'user', user.id, null, null, ip, ua);

    return res.json({
      success: true,
      token: accessToken,
      user: {
        id: user.id,
        username: user.username,
        fullName: user.full_name,
        role: user.role,
        permissions: typeof user.permissions === 'string' ? JSON.parse(user.permissions) : user.permissions
      }
    });

  } catch (err) {
    console.error('Login error:', err);
    return res.status(500).json({ success: false, message: 'خطای سرور' });
  }
});

// POST /api/auth/logout
router.post('/logout', verifyToken, (req, res) => {
  auditLog(req.user.id, 'logout', 'user', req.user.id, null, null, req.ip, req.headers['user-agent']);
  res.json({ success: true, message: 'با موفقیت خارج شدید' });
});

// GET /api/auth/me
router.get('/me', verifyToken, (req, res) => {
  const user = db.prepare('SELECT id, username, full_name, email, role, permissions, last_login FROM users WHERE id = ?').get(req.user.id);
  if (!user) return res.status(404).json({ success: false, message: 'کاربر یافت نشد' });

  res.json({
    success: true,
    user: {
      ...user,
      permissions: typeof user.permissions === 'string' ? JSON.parse(user.permissions) : user.permissions
    }
  });
});

// POST /api/auth/change-password
// BUG FIX: Removed overly strict regex requirement that confused users
// Now requires min 8 chars with at least one uppercase and one digit (documented clearly)
router.post('/change-password', verifyToken, [
  body('currentPassword').notEmpty().withMessage('رمز فعلی الزامی است'),
  body('newPassword')
    .isLength({ min: 8 }).withMessage('رمز جدید باید حداقل ۸ کاراکتر باشد')
    .matches(/^(?=.*[A-Z])(?=.*[0-9])/).withMessage('رمز باید شامل حداقل یک حرف بزرگ انگلیسی و یک عدد باشد')
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, message: errors.array()[0].msg });
  }

  const { currentPassword, newPassword } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);

  const isValid = await bcrypt.compare(currentPassword, user.password);
  if (!isValid) {
    return res.status(400).json({ success: false, message: 'رمز عبور فعلی اشتباه است' });
  }

  // Prevent reusing same password
  const isSame = await bcrypt.compare(newPassword, user.password);
  if (isSame) {
    return res.status(400).json({ success: false, message: 'رمز جدید نمی‌تواند با رمز فعلی یکسان باشد' });
  }

  const hashed = await bcrypt.hash(newPassword, 12);
  db.prepare(`UPDATE users SET password = ?, updated_at = datetime('now') WHERE id = ?`).run(hashed, user.id);

  auditLog(req.user.id, 'change_password', 'user', user.id, null, null, req.ip, req.headers['user-agent']);

  res.json({ success: true, message: 'رمز عبور با موفقیت تغییر یافت' });
});

module.exports = router;
