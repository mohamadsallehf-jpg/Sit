// middleware/auth.js - JWT Authentication & Authorization
const jwt = require('jsonwebtoken');
const { db } = require('../db/database');

const JWT_SECRET = process.env.JWT_SECRET || 'change_this_secret_minimum_64_chars';

// Generate tokens
const generateTokens = (user) => {
  const payload = {
    id: user.id,
    username: user.username,
    role: user.role,
    permissions: typeof user.permissions === 'string' 
      ? JSON.parse(user.permissions) 
      : user.permissions
  };
  
  const accessToken = jwt.sign(payload, JWT_SECRET, { 
    expiresIn: process.env.JWT_EXPIRES_IN || '8h',
    issuer: 'payment-system',
    audience: 'web-client'
  });
  
  return { accessToken };
};

// Verify JWT token
const verifyToken = (req, res, next) => {
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.startsWith('Bearer ') 
    ? authHeader.slice(7) 
    : req.cookies?.token;
  
  if (!token) {
    return res.status(401).json({ success: false, message: 'احراز هویت الزامی است' });
  }
  
  try {
    const decoded = jwt.verify(token, JWT_SECRET, {
      issuer: 'payment-system',
      audience: 'web-client'
    });
    
    // Verify user still exists and is active
    const user = db.prepare('SELECT id, role, is_active, permissions FROM users WHERE id = ?').get(decoded.id);
    
    if (!user || !user.is_active) {
      return res.status(401).json({ success: false, message: 'حساب کاربری غیرفعال یا حذف شده است' });
    }
    
    req.user = {
      ...decoded,
      permissions: typeof user.permissions === 'string' 
        ? JSON.parse(user.permissions) 
        : user.permissions
    };
    
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ success: false, message: 'نشست منقضی شده، دوباره وارد شوید', expired: true });
    }
    return res.status(401).json({ success: false, message: 'توکن نامعتبر است' });
  }
};

// Owner only
const requireOwner = (req, res, next) => {
  if (!req.user || req.user.role !== 'owner') {
    return res.status(403).json({ success: false, message: 'فقط مالک سیستم به این بخش دسترسی دارد' });
  }
  next();
};

// Admin or owner
const requireAdmin = (req, res, next) => {
  if (!req.user || !['owner', 'admin'].includes(req.user.role)) {
    return res.status(403).json({ success: false, message: 'دسترسی غیرمجاز' });
  }
  next();
};

// Permission check factory
const requirePermission = (permission) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ success: false, message: 'احراز هویت الزامی است' });
    }
    
    // Owner has all permissions
    if (req.user.role === 'owner' || req.user.permissions?.all === true) {
      return next();
    }
    
    const permissions = req.user.permissions || {};
    
    if (!permissions[permission]) {
      return res.status(403).json({ 
        success: false, 
        message: `شما به دسترسی "${permissionLabels[permission] || permission}" نیاز دارید` 
      });
    }
    
    next();
  };
};

const permissionLabels = {
  'view_transactions': 'مشاهده تراکنش‌ها',
  'review_receipts': 'بررسی رسیدها',
  'manage_transactions': 'مدیریت تراکنش‌ها',
  'view_users': 'مشاهده کاربران',
  'manage_users': 'مدیریت کاربران',
  'view_reports': 'مشاهده گزارشات',
  'manage_settings': 'مدیریت تنظیمات',
  'view_audit_logs': 'مشاهده لاگ‌ها',
  'send_notifications': 'ارسال نوتیفیکیشن'
};

const ALL_PERMISSIONS = Object.keys(permissionLabels);

module.exports = { generateTokens, verifyToken, requireOwner, requireAdmin, requirePermission, ALL_PERMISSIONS, permissionLabels };
