// middleware/upload.js - Secure File Upload (Fixed)
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');

const UPLOAD_DIR = path.join(__dirname, '../public/uploads');
if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}

const ALLOWED_TYPES = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
const MAX_SIZE = (parseInt(process.env.UPLOAD_MAX_SIZE_MB) || 5) * 1024 * 1024;

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const date = new Date();
    const dir = path.join(UPLOAD_DIR,
      date.getFullYear().toString(),
      (date.getMonth() + 1).toString().padStart(2, '0')
    );
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const safeExt = ['.jpg', '.jpeg', '.png', '.webp'].includes(ext) ? ext : '.jpg';
    cb(null, `receipt_${uuidv4()}${safeExt}`);
  }
});

const fileFilter = (req, file, cb) => {
  if (!ALLOWED_TYPES.includes(file.mimetype)) {
    return cb(new Error('فقط فایل‌های تصویری مجاز هستند (JPG, PNG, WebP)'), false);
  }
  cb(null, true);
};

const upload = multer({ storage, fileFilter, limits: { fileSize: MAX_SIZE, files: 1 } });

// BUG FIX: Was using wrong destructuring { sharp } = require('sharp')
// Now actually validates image magic bytes to prevent MIME spoofing
const validateImageFile = async (filePath) => {
  try {
    const sharp = require('sharp');
    const metadata = await sharp(filePath).metadata();
    return ['jpeg', 'png', 'webp', 'gif'].includes(metadata.format);
  } catch {
    try { fs.unlinkSync(filePath); } catch {}
    return false;
  }
};

const handleUploadError = (err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    if (err.code === 'LIMIT_FILE_SIZE') {
      return res.status(400).json({ success: false, message: `حجم فایل نباید بیشتر از ${process.env.UPLOAD_MAX_SIZE_MB || 5} مگابایت باشد` });
    }
    return res.status(400).json({ success: false, message: 'خطا در آپلود فایل: ' + err.message });
  }
  if (err) return res.status(400).json({ success: false, message: err.message });
  next();
};

const getFileUrl = (filePath) => {
  if (!filePath) return null;
  const relativePath = path.relative(path.join(__dirname, '../public'), filePath);
  return '/' + relativePath.replace(/\\/g, '/');
};

module.exports = { upload, handleUploadError, getFileUrl, validateImageFile };
