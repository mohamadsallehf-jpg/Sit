// middleware/security.js - Enterprise Security Layer (Fixed)
const rateLimit = require('express-rate-limit');
const slowDown = require('express-slow-down');
const helmet = require('helmet');
const { logSecurityEvent } = require('../db/database');

// ==================== RATE LIMITERS ====================

const apiLimiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000,
  max: parseInt(process.env.RATE_LIMIT_MAX) || 100,
  standardHeaders: true,
  legacyHeaders: false,
  skipSuccessfulRequests: false,
  handler: (req, res) => {
    logSecurityEvent('rate_limit_exceeded', req.ip, req.headers['user-agent'], { path: req.path }, 'medium');
    res.status(429).json({ success: false, message: 'درخواست‌های زیادی ارسال کرده‌اید. لطفاً چند دقیقه صبر کنید.' });
  }
});

// BUG FIX: skipSuccessfulRequests was false — after 10 successful logins, you'd be locked out
// Now only FAILED attempts count toward rate limiting
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 15,
  skipSuccessfulRequests: true, // FIX: only count failed attempts
  handler: (req, res) => {
    logSecurityEvent('auth_rate_limit', req.ip, req.headers['user-agent'], { path: req.path, body: req.body?.username }, 'high');
    res.status(429).json({ success: false, message: 'تعداد تلاش‌های ورود از حد مجاز گذشته. ۱۵ دقیقه صبر کنید.' });
  }
});

const uploadLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  max: 20,
  handler: (req, res) => {
    res.status(429).json({ success: false, message: 'تعداد آپلود از حد مجاز گذشته. ۱۰ دقیقه صبر کنید.' });
  }
});

const speedLimiter = slowDown({
  windowMs: 15 * 60 * 1000,
  delayAfter: 50,
  delayMs: (hits) => hits * 200,
  maxDelayMs: 5000
});

// ==================== HELMET CONFIG ====================
const helmetConfig = helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'", "https://cdn.tailwindcss.com", "https://fonts.googleapis.com"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com", "https://cdn.tailwindcss.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      imgSrc: ["'self'", "data:", "blob:"],
      connectSrc: ["'self'"],
      frameSrc: ["'none'"],
      objectSrc: ["'none'"],
      upgradeInsecureRequests: process.env.NODE_ENV === 'production' ? [] : null
    }
  },
  crossOriginEmbedderPolicy: false,
  hsts: {
    maxAge: 31536000,
    includeSubDomains: true,
    preload: true
  }
});

// ==================== SUSPICIOUS PATTERNS ====================
// BUG FIX: Previously these patterns were checked against BOTH URL and request body
// This caused false positives - e.g. "insert money into account" in a description field
// would be blocked. Now we only check URL for path traversal and XSS patterns.
// SQL injection patterns are only checked in URL params, not in user content fields.
const urlSuspiciousPatterns = [
  /(\.|%2E){2}(\/|%2F)/i,   // Path traversal
  /<script/i,                // XSS in URL
  /javascript:/i,            // JS injection in URL
];

const sqlPatterns = [
  /union\s+select/i,         // SQL injection
  /drop\s+table/i,           // SQL injection
  /exec(\s|\+)+(s|x)p\w+/i, // SQL stored proc injection
];

const requestInspector = (req, res, next) => {
  const url = decodeURIComponent(req.url || '');

  // Check URL for suspicious patterns
  for (const pattern of urlSuspiciousPatterns) {
    if (pattern.test(url)) {
      logSecurityEvent('suspicious_request_url', req.ip, req.headers['user-agent'], { url: req.url, pattern: pattern.toString() }, 'high');
      return res.status(400).json({ success: false, message: 'درخواست نامعتبر' });
    }
  }

  // Only check URL params for SQL injection, NOT body (avoids false positives)
  const urlOnly = url + JSON.stringify(req.query || {});
  for (const pattern of sqlPatterns) {
    if (pattern.test(urlOnly)) {
      logSecurityEvent('sql_injection_attempt', req.ip, req.headers['user-agent'], { url: req.url }, 'critical');
      return res.status(400).json({ success: false, message: 'درخواست نامعتبر' });
    }
  }

  next();
};

// ==================== IP FILTERING ====================
const blockedIPs = new Set();

const ipFilter = (req, res, next) => {
  if (blockedIPs.has(req.ip)) {
    return res.status(403).json({ success: false, message: 'دسترسی مسدود شده' });
  }
  next();
};

const blockIP = (ip, duration = 3600000) => {
  blockedIPs.add(ip);
  setTimeout(() => blockedIPs.delete(ip), duration);
};

// ==================== MAINTENANCE MODE ====================
const maintenanceCheck = (req, res, next) => {
  const { getSetting } = require('../db/database');
  // Allow auth and owner routes during maintenance
  if (getSetting('maintenance_mode') === 'true' &&
      !req.path.startsWith('/api/owner') &&
      !req.path.startsWith('/api/auth')) {
    return res.status(503).json({ success: false, message: 'سیستم در حال بروزرسانی است. لطفاً بعداً تلاش کنید.' });
  }
  next();
};

module.exports = {
  apiLimiter,
  authLimiter,
  uploadLimiter,
  speedLimiter,
  helmetConfig,
  requestInspector,
  ipFilter,
  blockIP,
  maintenanceCheck
};
