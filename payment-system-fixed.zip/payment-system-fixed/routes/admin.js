// routes/admin.js - Admin Panel Routes (Permission-Based)
const express = require('express');
const router = express.Router();
const path = require('path');
const { db, auditLog, getSetting } = require('../db/database');
const { verifyToken, requireAdmin, requirePermission } = require('../middleware/auth');
const { sendEmail, emailTemplates } = require('../services/email');
const { notifications: tgNotifications } = require('../services/telegram');

router.use(verifyToken, requireAdmin);

// ==================== DASHBOARD ====================
router.get('/dashboard', (req, res) => {
  const isOwner = req.user.role === 'owner';
  const perms = req.user.permissions || {};
  
  const today = new Date().toISOString().split('T')[0];
  
  const stats = {};
  
  if (isOwner || perms.view_transactions) {
    stats.pending = db.prepare("SELECT COUNT(*) as c FROM transactions WHERE status = 'pending_review'").get().c;
    stats.approvedToday = db.prepare("SELECT COUNT(*) as c FROM transactions WHERE status = 'approved' AND date(created_at) = ?").get(today).c;
    stats.totalToday = db.prepare("SELECT COUNT(*) as c FROM transactions WHERE date(created_at) = ?").get(today).c;
    stats.revenueToday = db.prepare("SELECT COALESCE(SUM(amount),0) as s FROM transactions WHERE status = 'approved' AND date(created_at) = ?").get(today).s;
  }
  
  if (isOwner || perms.review_receipts) {
    stats.pendingReceipts = db.prepare("SELECT COUNT(*) as c FROM transactions WHERE status = 'pending_review' AND receipt_image IS NOT NULL").get().c;
  }
  
  // Recent activity for this admin
  const recentReviewed = db.prepare(`
    SELECT t.tracking_code, t.status, t.amount, t.reviewed_at
    FROM transactions t
    WHERE t.reviewed_by = ?
    ORDER BY t.reviewed_at DESC LIMIT 5
  `).all(req.user.id);
  
  res.json({ success: true, stats, recentReviewed });
});

// ==================== RECEIPT MANAGEMENT ====================
router.get('/receipts', requirePermission('review_receipts'), (req, res) => {
  const { page = 1, limit = 20, status = 'pending_review' } = req.query;
  const offset = (parseInt(page) - 1) * parseInt(limit);
  
  const validStatuses = ['pending_review', 'approved', 'rejected', 'all'];
  const statusFilter = validStatuses.includes(status) ? status : 'pending_review';
  
  let where = statusFilter === 'all' ? "t.receipt_image IS NOT NULL" : "t.status = ? AND t.receipt_image IS NOT NULL";
  const params = statusFilter === 'all' ? [] : [statusFilter];
  
  const total = db.prepare(`SELECT COUNT(*) as c FROM transactions t WHERE ${where}`).get(...params).c;
  
  const receipts = db.prepare(`
    SELECT t.*, bc.card_number, bc.bank_name, bc.card_holder,
           u.username as reviewer_username
    FROM transactions t
    LEFT JOIN bank_cards bc ON t.card_id = bc.id
    LEFT JOIN users u ON t.reviewed_by = u.id
    WHERE ${where}
    ORDER BY t.receipt_uploaded_at DESC
    LIMIT ? OFFSET ?
  `).all(...params, parseInt(limit), offset);
  
  res.json({ success: true, receipts, total });
});

// Approve receipt
router.post('/receipts/:id/approve', requirePermission('review_receipts'), async (req, res) => {
  const { id } = req.params;
  const transaction = db.prepare("SELECT * FROM transactions WHERE id = ? AND receipt_image IS NOT NULL").get(id);
  
  if (!transaction) {
    return res.status(404).json({ success: false, message: 'تراکنش یافت نشد' });
  }
  
  if (!['pending_review', 'pending'].includes(transaction.status)) {
    return res.status(400).json({ success: false, message: 'این تراکنش قبلاً بررسی شده است' });
  }
  
  db.prepare(`
    UPDATE transactions SET
      status = 'approved',
      approved_by = ?,
      approved_at = datetime('now'),
      reviewed_by = ?,
      reviewed_at = datetime('now'),
      updated_at = datetime('now')
    WHERE id = ?
  `).run(req.user.id, req.user.id, id);
  
  const updated = db.prepare('SELECT * FROM transactions WHERE id = ?').get(id);
  
  auditLog(req.user.id, 'approve_receipt', 'transaction', id, transaction, { status: 'approved' }, req.ip, req.headers['user-agent']);
  
  // Send email if enabled
  if (getSetting('email_notifications') === 'true' && updated.customer_email) {
    const template = emailTemplates.receiptApproved({
      customerName: updated.customer_name,
      customerEmail: updated.customer_email,
      amount: updated.amount,
      trackingCode: updated.tracking_code,
      approvedAt: new Date().toLocaleString('fa-IR')
    });
    
    sendEmail(updated.customer_email, template).catch(console.error);
  }
  
  // Telegram notification
  if (getSetting('telegram_notifications') === 'true') {
    tgNotifications.receiptApproved({ ...updated, approvedBy: req.user.username }).catch(console.error);
  }
  
  res.json({ success: true, message: 'رسید با موفقیت تأیید شد و ایمیل ارسال گردید' });
});

// Reject receipt
router.post('/receipts/:id/reject', requirePermission('review_receipts'), async (req, res) => {
  const { id } = req.params;
  const { reason } = req.body;
  
  const transaction = db.prepare("SELECT * FROM transactions WHERE id = ? AND receipt_image IS NOT NULL").get(id);
  
  if (!transaction) {
    return res.status(404).json({ success: false, message: 'تراکنش یافت نشد' });
  }
  
  if (!['pending_review', 'pending'].includes(transaction.status)) {
    return res.status(400).json({ success: false, message: 'این تراکنش قبلاً بررسی شده است' });
  }
  
  db.prepare(`
    UPDATE transactions SET
      status = 'rejected',
      rejection_reason = ?,
      reviewed_by = ?,
      reviewed_at = datetime('now'),
      updated_at = datetime('now')
    WHERE id = ?
  `).run(reason || 'رسید نامعتبر است', req.user.id, id);
  
  auditLog(req.user.id, 'reject_receipt', 'transaction', id, transaction, { status: 'rejected', reason }, req.ip, req.headers['user-agent']);
  
  const updated = db.prepare('SELECT * FROM transactions WHERE id = ?').get(id);
  
  // Send email
  if (getSetting('email_notifications') === 'true' && updated.customer_email) {
    const template = emailTemplates.receiptRejected({
      customerName: updated.customer_name,
      customerEmail: updated.customer_email,
      amount: updated.amount,
      trackingCode: updated.tracking_code,
      rejectionReason: reason,
      rejectedAt: new Date().toLocaleString('fa-IR')
    });
    
    sendEmail(updated.customer_email, template).catch(console.error);
  }
  
  // Telegram
  if (getSetting('telegram_notifications') === 'true') {
    tgNotifications.receiptRejected({ ...updated, rejectionReason: reason }).catch(console.error);
  }
  
  res.json({ success: true, message: 'رسید رد شد و کاربر مطلع گردید' });
});

// ==================== TRANSACTIONS ====================
router.get('/transactions', requirePermission('view_transactions'), (req, res) => {
  const { page = 1, limit = 20, status, search } = req.query;
  const offset = (parseInt(page) - 1) * parseInt(limit);
  
  let where = '1=1';
  const params = [];
  
  if (status) { where += ' AND t.status = ?'; params.push(status); }
  if (search) {
    where += ' AND (t.tracking_code LIKE ? OR t.customer_email LIKE ? OR t.customer_name LIKE ?)';
    params.push(`%${search}%`, `%${search}%`, `%${search}%`);
  }
  
  const total = db.prepare(`SELECT COUNT(*) as c FROM transactions t WHERE ${where}`).get(...params).c;
  const transactions = db.prepare(`
    SELECT t.*, bc.bank_name, bc.card_holder
    FROM transactions t
    LEFT JOIN bank_cards bc ON t.card_id = bc.id
    WHERE ${where}
    ORDER BY t.created_at DESC
    LIMIT ? OFFSET ?
  `).all(...params, parseInt(limit), offset);
  
  res.json({ success: true, transactions, total });
});

// ==================== PROFILE ====================
router.get('/profile', (req, res) => {
  const user = db.prepare('SELECT id, username, full_name, email, telegram_id, role, permissions, last_login FROM users WHERE id = ?').get(req.user.id);
  res.json({ 
    success: true, 
    user: {
      ...user,
      permissions: typeof user.permissions === 'string' ? JSON.parse(user.permissions) : user.permissions
    }
  });
});

module.exports = router;
