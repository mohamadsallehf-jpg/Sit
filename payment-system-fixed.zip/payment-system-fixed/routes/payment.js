// routes/payment.js - Public Payment Routes
const express = require('express');
const router = express.Router();
const path = require('path');
const { body, validationResult } = require('express-validator');
const xss = require('xss');
const { db, getSetting, generateTrackingCode, logSecurityEvent } = require('../db/database');
const { upload, handleUploadError, getFileUrl } = require('../middleware/upload');
const { uploadLimiter, apiLimiter } = require('../middleware/security');
const { notifications: tgNotifications } = require('../services/telegram');

// ==================== GET ACTIVE CARD ====================
router.get('/card', (req, res) => {
  const card = db.prepare('SELECT id, card_number, card_holder, bank_name FROM bank_cards WHERE is_active = 1 ORDER BY display_order ASC LIMIT 1').get();
  
  if (!card) {
    return res.status(404).json({ success: false, message: 'در حال حاضر کارت فعالی وجود ندارد' });
  }
  
  const siteName = getSetting('site_name') || 'سیستم پرداخت';
  const telegramSupport = getSetting('telegram_support') || '@Onicor';
  
  res.json({ success: true, card, siteName, telegramSupport });
});

// ==================== CREATE TRANSACTION ====================
router.post('/create', apiLimiter, [
  body('customerEmail').isEmail().normalizeEmail().withMessage('ایمیل نامعتبر است'),
  body('customerName').trim().notEmpty().isLength({ max: 100 }).withMessage('نام الزامی است'),
  body('customerPhone').optional().trim().isMobilePhone('fa-IR'),
  body('amount').isInt({ min: 1000, max: 100000000 }).withMessage('مبلغ نامعتبر'),
  body('description').optional().trim().isLength({ max: 500 })
], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array(), message: errors.array()[0].msg });
  }
  
  // Check maintenance mode
  if (getSetting('maintenance_mode') === 'true') {
    return res.status(503).json({ success: false, message: 'سیستم در حال بروزرسانی است' });
  }
  
  // Check daily limit
  const today = new Date().toISOString().split('T')[0];
  const todayCount = db.prepare("SELECT COUNT(*) as c FROM transactions WHERE date(created_at) = ?").get(today).c;
  const maxDaily = parseInt(getSetting('max_daily_transactions') || '100');
  
  if (todayCount >= maxDaily) {
    return res.status(429).json({ success: false, message: 'ظرفیت پردازش امروز تکمیل شده. فردا مراجعه کنید.' });
  }
  
  const { customerEmail, customerName, customerPhone, amount, description } = req.body;
  
  // Get active card
  const card = db.prepare('SELECT id FROM bank_cards WHERE is_active = 1 ORDER BY display_order ASC LIMIT 1').get();
  if (!card) {
    return res.status(503).json({ success: false, message: 'در حال حاضر امکان پرداخت وجود ندارد' });
  }
  
  const trackingCode = generateTrackingCode();
  const expiryMinutes = parseInt(getSetting('transaction_expiry_minutes') || '60');
  const expiresAt = new Date(Date.now() + expiryMinutes * 60000).toISOString();
  
  const result = db.prepare(`
    INSERT INTO transactions (
      tracking_code, customer_name, customer_email, customer_phone,
      amount, description, card_id, status, expires_at, ip_address, user_agent
    ) VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?)
  `).run(
    trackingCode,
    xss(customerName),
    customerEmail,
    customerPhone || '',
    parseInt(amount),
    xss(description || ''),
    card.id,
    expiresAt,
    req.ip,
    req.headers['user-agent']
  );
  
  res.json({
    success: true,
    trackingCode,
    message: 'تراکنش ایجاد شد',
    expiresAt,
    transactionId: result.lastInsertRowid
  });
});

// ==================== UPLOAD RECEIPT ====================
router.post('/upload-receipt', uploadLimiter, (req, res, next) => {
  upload.single('receipt')(req, res, (err) => {
    if (err) return handleUploadError(err, req, res, next);
    next();
  });
}, [
  body('trackingCode').trim().matches(/^PAY-[A-Z0-9]{8}$/).withMessage('کد رهگیری نامعتبر')
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, message: errors.array()[0].msg });
  }
  
  if (!req.file) {
    return res.status(400).json({ success: false, message: 'فایل رسید الزامی است' });
  }
  
  const { trackingCode } = req.body;
  
  const transaction = db.prepare("SELECT * FROM transactions WHERE tracking_code = ?").get(trackingCode);
  
  if (!transaction) {
    return res.status(404).json({ success: false, message: 'کد رهگیری یافت نشد' });
  }
  
  if (transaction.status === 'approved') {
    return res.status(400).json({ success: false, message: 'این تراکنش قبلاً تأیید شده است' });
  }
  
  if (transaction.status === 'rejected') {
    return res.status(400).json({ success: false, message: 'این تراکنش رد شده است' });
  }
  
  // Check expiry
  if (transaction.expires_at && new Date(transaction.expires_at) < new Date()) {
    db.prepare("UPDATE transactions SET status = 'expired' WHERE id = ?").run(transaction.id);
    return res.status(400).json({ success: false, message: 'مهلت پرداخت منقضی شده است' });
  }
  
  // If already has receipt, delete old file
  if (transaction.receipt_image) {
    try {
      const fs = require('fs');
      const oldPath = path.join(__dirname, '../public', transaction.receipt_image);
      if (fs.existsSync(oldPath)) fs.unlinkSync(oldPath);
    } catch (e) {}
  }
  
  const receiptUrl = getFileUrl(req.file.path);
  
  db.prepare(`
    UPDATE transactions SET
      receipt_image = ?,
      receipt_uploaded_at = datetime('now'),
      status = 'pending_review',
      updated_at = datetime('now')
    WHERE id = ?
  `).run(receiptUrl, transaction.id);
  
  // Telegram notification
  if (getSetting('telegram_notifications') === 'true') {
    const updated = db.prepare('SELECT * FROM transactions WHERE id = ?').get(transaction.id);
    tgNotifications.newReceipt({ ...updated, receiptImage: receiptUrl }).catch(console.error);
  }
  
  // Add admin notification
  const admins = db.prepare("SELECT id FROM users WHERE role IN ('owner', 'admin') AND is_active = 1").all();
  const { addNotification } = require('../db/database');
  for (const admin of admins) {
    addNotification(admin.id, 'new_receipt', 'رسید جدید', 
      `رسید تراکنش ${trackingCode} آپلود شد و منتظر بررسی است`, { trackingCode });
  }
  
  res.json({ 
    success: true, 
    message: 'رسید با موفقیت آپلود شد. پس از بررسی، ایمیل دریافت خواهید کرد.',
    trackingCode
  });
});

// ==================== TRACK TRANSACTION ====================
router.get('/track/:trackingCode', (req, res) => {
  const { trackingCode } = req.params;
  
  if (!/^PAY-[A-Z0-9]{8}$/.test(trackingCode)) {
    return res.status(400).json({ success: false, message: 'کد رهگیری نامعتبر' });
  }
  
  const transaction = db.prepare(`
    SELECT t.tracking_code, t.status, t.amount, t.description, 
           t.receipt_uploaded_at, t.rejection_reason, t.created_at, t.expires_at,
           bc.bank_name, bc.card_holder
    FROM transactions t
    LEFT JOIN bank_cards bc ON t.card_id = bc.id
    WHERE t.tracking_code = ?
  `).get(trackingCode);
  
  if (!transaction) {
    return res.status(404).json({ success: false, message: 'تراکنش یافت نشد' });
  }
  
  const statusMessages = {
    pending: 'در انتظار آپلود رسید',
    pending_review: 'رسید دریافت شد، در حال بررسی...',
    approved: '✅ پرداخت تأیید شد',
    rejected: '❌ پرداخت رد شد',
    expired: '⏰ منقضی شده',
    refunded: '↩️ بازگشت وجه'
  };
  
  res.json({
    success: true,
    transaction: {
      ...transaction,
      statusMessage: statusMessages[transaction.status] || transaction.status
    }
  });
});

// ==================== GET ACTIVE GATEWAYS (public) ====================
router.get('/gateways/active', (req, res) => {
  const gateways = db.prepare('SELECT name, display_name FROM payment_gateways WHERE is_active = 1').all();
  res.json({ success: true, gateways });
});

module.exports = router;
