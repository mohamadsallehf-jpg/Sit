// routes/owner.js - Owner Panel Routes (Full Control)
const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const { body, validationResult, param } = require('express-validator');
const { db, auditLog, getSetting, setSetting, addNotification } = require('../db/database');
const { verifyToken, requireOwner, ALL_PERMISSIONS, permissionLabels } = require('../middleware/auth');
const { notifications: tgNotifications } = require('../services/telegram');

// All owner routes require owner role
router.use(verifyToken, requireOwner);

// ==================== DASHBOARD ====================
router.get('/dashboard', (req, res) => {
  const today = new Date().toISOString().split('T')[0];
  const thisMonth = today.slice(0, 7);
  
  const stats = {
    transactions: {
      total: db.prepare('SELECT COUNT(*) as c FROM transactions').get().c,
      pending: db.prepare("SELECT COUNT(*) as c FROM transactions WHERE status = 'pending_review'").get().c,
      approved: db.prepare("SELECT COUNT(*) as c FROM transactions WHERE status = 'approved'").get().c,
      rejected: db.prepare("SELECT COUNT(*) as c FROM transactions WHERE status = 'rejected'").get().c,
      today: db.prepare("SELECT COUNT(*) as c FROM transactions WHERE date(created_at) = ?").get(today).c,
    },
    revenue: {
      total: db.prepare("SELECT COALESCE(SUM(amount),0) as s FROM transactions WHERE status = 'approved'").get().s,
      today: db.prepare("SELECT COALESCE(SUM(amount),0) as s FROM transactions WHERE status = 'approved' AND date(created_at) = ?").get(today).s,
      thisMonth: db.prepare("SELECT COALESCE(SUM(amount),0) as s FROM transactions WHERE status = 'approved' AND strftime('%Y-%m', created_at) = ?").get(thisMonth).s,
    },
    admins: db.prepare("SELECT COUNT(*) as c FROM users WHERE role = 'admin' AND is_active = 1").get().c,
    cards: db.prepare('SELECT COUNT(*) as c FROM bank_cards WHERE is_active = 1').get().c,
    pendingReceipts: db.prepare("SELECT COUNT(*) as c FROM transactions WHERE status = 'pending_review'").get().c,
  };
  
  const recentTransactions = db.prepare(`
    SELECT t.*, bc.card_holder, bc.bank_name 
    FROM transactions t 
    LEFT JOIN bank_cards bc ON t.card_id = bc.id 
    ORDER BY t.created_at DESC LIMIT 10
  `).all();
  
  const dailyRevenue = db.prepare(`
    SELECT date(created_at) as date, COUNT(*) as count, COALESCE(SUM(amount),0) as total
    FROM transactions WHERE status = 'approved' AND created_at >= date('now', '-30 days')
    GROUP BY date(created_at) ORDER BY date ASC
  `).all();
  
  res.json({ success: true, stats, recentTransactions, dailyRevenue });
});

// ==================== BANK CARDS ====================
router.get('/cards', (req, res) => {
  const cards = db.prepare('SELECT * FROM bank_cards ORDER BY display_order ASC, created_at DESC').all();
  res.json({ success: true, cards });
});

router.post('/cards', [
  body('cardNumber').trim().matches(/^\d{4}-?\d{4}-?\d{4}-?\d{4}$/).withMessage('شماره کارت نامعتبر'),
  body('cardHolder').trim().notEmpty().isLength({ max: 100 }),
  body('bankName').trim().notEmpty().isLength({ max: 100 }),
  body('sheba').optional().trim(),
  body('note').optional().trim().isLength({ max: 500 })
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ success: false, errors: errors.array() });
  
  const { cardNumber, cardHolder, bankName, sheba, note, dailyLimit } = req.body;
  const formatted = cardNumber.replace(/-/g, '').replace(/(.{4})/g, '$1-').slice(0, -1);
  
  const result = db.prepare(`
    INSERT INTO bank_cards (card_number, card_holder, bank_name, sheba, note, daily_limit, created_by)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(formatted, cardHolder, bankName, sheba || '', note || '', dailyLimit || 0, req.user.id);
  
  auditLog(req.user.id, 'create_card', 'bank_card', result.lastInsertRowid, null, req.body, req.ip, req.headers['user-agent']);
  
  res.json({ success: true, message: 'کارت بانکی با موفقیت اضافه شد' });
});

router.put('/cards/:id', (req, res) => {
  const { id } = req.params;
  const card = db.prepare('SELECT * FROM bank_cards WHERE id = ?').get(id);
  if (!card) return res.status(404).json({ success: false, message: 'کارت یافت نشد' });
  
  const { cardHolder, bankName, sheba, note, is_active, display_order, daily_limit } = req.body;
  
  db.prepare(`
    UPDATE bank_cards SET 
      card_holder = COALESCE(?, card_holder),
      bank_name = COALESCE(?, bank_name),
      sheba = COALESCE(?, sheba),
      note = COALESCE(?, note),
      is_active = COALESCE(?, is_active),
      display_order = COALESCE(?, display_order),
      daily_limit = COALESCE(?, daily_limit),
      updated_at = datetime('now')
    WHERE id = ?
  `).run(cardHolder, bankName, sheba, note, is_active !== undefined ? is_active : null, display_order, daily_limit, id);
  
  auditLog(req.user.id, 'update_card', 'bank_card', id, card, req.body, req.ip, req.headers['user-agent']);
  res.json({ success: true, message: 'کارت با موفقیت ویرایش شد' });
});

router.delete('/cards/:id', (req, res) => {
  const { id } = req.params;
  const card = db.prepare('SELECT * FROM bank_cards WHERE id = ?').get(id);
  if (!card) return res.status(404).json({ success: false, message: 'کارت یافت نشد' });
  
  const hasTransactions = db.prepare("SELECT COUNT(*) as c FROM transactions WHERE card_id = ?").get(id).c;
  if (hasTransactions > 0) {
    db.prepare("UPDATE bank_cards SET is_active = 0 WHERE id = ?").run(id);
    return res.json({ success: true, message: 'کارت غیرفعال شد (دارای تراکنش است)' });
  }
  
  db.prepare('DELETE FROM bank_cards WHERE id = ?').run(id);
  auditLog(req.user.id, 'delete_card', 'bank_card', id, card, null, req.ip, req.headers['user-agent']);
  res.json({ success: true, message: 'کارت با موفقیت حذف شد' });
});

// ==================== ADMIN MANAGEMENT ====================
router.get('/admins', (req, res) => {
  const admins = db.prepare(`
    SELECT id, username, full_name, email, telegram_id, permissions, is_active, last_login, created_at
    FROM users WHERE role = 'admin' ORDER BY created_at DESC
  `).all().map(a => ({
    ...a,
    permissions: typeof a.permissions === 'string' ? JSON.parse(a.permissions) : a.permissions
  }));
  
  res.json({ success: true, admins, availablePermissions: ALL_PERMISSIONS, permissionLabels });
});

router.post('/admins', [
  body('username').trim().isAlphanumeric().isLength({ min: 3, max: 30 }),
  body('password').isLength({ min: 8 }),
  body('fullName').trim().notEmpty().isLength({ max: 100 }),
  body('email').optional().isEmail().normalizeEmail(),
  body('permissions').isObject()
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ success: false, errors: errors.array() });
  
  const { username, password, fullName, email, telegramId, permissions } = req.body;
  
  const exists = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
  if (exists) return res.status(400).json({ success: false, message: 'این نام کاربری قبلاً استفاده شده' });
  
  // Validate permissions
  const validPerms = {};
  for (const perm of ALL_PERMISSIONS) {
    if (permissions[perm]) validPerms[perm] = true;
  }
  
  const hashed = await bcrypt.hash(password, 12);
  
  const result = db.prepare(`
    INSERT INTO users (role, username, password, full_name, email, telegram_id, permissions)
    VALUES ('admin', ?, ?, ?, ?, ?, ?)
  `).run(username, hashed, fullName, email || '', telegramId || '', JSON.stringify(validPerms));
  
  auditLog(req.user.id, 'create_admin', 'user', result.lastInsertRowid, null, { username, fullName, permissions: validPerms }, req.ip, req.headers['user-agent']);
  
  await tgNotifications.newAdmin({ username, fullName });
  
  res.json({ success: true, message: 'ادمین با موفقیت ایجاد شد' });
});

router.put('/admins/:id', [
  body('permissions').optional().isObject(),
  body('password').optional().isLength({ min: 8 }),
  body('fullName').optional().trim().isLength({ max: 100 }),
  body('email').optional().isEmail().normalizeEmail()
], async (req, res) => {
  const { id } = req.params;
  const admin = db.prepare("SELECT * FROM users WHERE id = ? AND role = 'admin'").get(id);
  if (!admin) return res.status(404).json({ success: false, message: 'ادمین یافت نشد' });
  
  const { fullName, email, telegramId, permissions, is_active, password } = req.body;
  
  let newPassword = admin.password;
  if (password) newPassword = await bcrypt.hash(password, 12);
  
  let validPerms = typeof admin.permissions === 'string' ? JSON.parse(admin.permissions) : admin.permissions;
  if (permissions) {
    validPerms = {};
    for (const perm of ALL_PERMISSIONS) {
      if (permissions[perm]) validPerms[perm] = true;
    }
  }
  
  db.prepare(`
    UPDATE users SET 
      full_name = COALESCE(?, full_name),
      email = COALESCE(?, email),
      telegram_id = COALESCE(?, telegram_id),
      permissions = ?,
      is_active = COALESCE(?, is_active),
      password = ?,
      updated_at = datetime('now')
    WHERE id = ?
  `).run(fullName, email, telegramId, JSON.stringify(validPerms), is_active !== undefined ? (is_active ? 1 : 0) : null, newPassword, id);
  
  auditLog(req.user.id, 'update_admin', 'user', id, admin, req.body, req.ip, req.headers['user-agent']);
  res.json({ success: true, message: 'ادمین با موفقیت ویرایش شد' });
});

router.delete('/admins/:id', (req, res) => {
  const { id } = req.params;
  const admin = db.prepare("SELECT * FROM users WHERE id = ? AND role = 'admin'").get(id);
  if (!admin) return res.status(404).json({ success: false, message: 'ادمین یافت نشد' });
  
  db.prepare('DELETE FROM users WHERE id = ?').run(id);
  auditLog(req.user.id, 'delete_admin', 'user', id, admin, null, req.ip, req.headers['user-agent']);
  res.json({ success: true, message: 'ادمین با موفقیت حذف شد' });
});

// ==================== PAYMENT GATEWAYS ====================
router.get('/gateways', (req, res) => {
  const gateways = db.prepare('SELECT * FROM payment_gateways').all().map(g => ({
    ...g,
    config: typeof g.config === 'string' ? JSON.parse(g.config) : g.config,
    // Mask API key
    api_key: g.api_key ? '••••••' + g.api_key.slice(-4) : null
  }));
  res.json({ success: true, gateways });
});

router.put('/gateways/:name', [
  body('apiKey').optional().trim(),
  body('merchantId').optional().trim(),
  body('sandbox').optional().isBoolean(),
  body('isActive').optional().isBoolean()
], (req, res) => {
  const { name } = req.params;
  const gw = db.prepare('SELECT * FROM payment_gateways WHERE name = ?').get(name);
  if (!gw) return res.status(404).json({ success: false, message: 'درگاه یافت نشد' });
  
  const { apiKey, merchantId, sandbox, isActive } = req.body;
  
  // Validate: if activating, require API key
  if (isActive && !apiKey && !gw.api_key) {
    return res.status(400).json({ success: false, message: 'برای فعال‌سازی درگاه، کلید API الزامی است' });
  }
  
  db.prepare(`
    UPDATE payment_gateways SET
      api_key = COALESCE(?, api_key),
      merchant_id = COALESCE(?, merchant_id),
      sandbox = COALESCE(?, sandbox),
      is_active = COALESCE(?, is_active),
      updated_at = datetime('now')
    WHERE name = ?
  `).run(apiKey, merchantId, sandbox !== undefined ? (sandbox ? 1 : 0) : null, isActive !== undefined ? (isActive ? 1 : 0) : null, name);
  
  auditLog(req.user.id, 'update_gateway', 'payment_gateway', name, gw, req.body, req.ip, req.headers['user-agent']);
  res.json({ success: true, message: 'تنظیمات درگاه به‌روزرسانی شد' });
});

// ==================== SETTINGS ====================
router.get('/settings', (req, res) => {
  const settings = db.prepare('SELECT * FROM settings ORDER BY key').all();
  const settingsObj = {};
  settings.forEach(s => settingsObj[s.key] = s.value);
  res.json({ success: true, settings: settingsObj });
});

router.put('/settings', (req, res) => {
  const { settings } = req.body;
  if (!settings || typeof settings !== 'object') {
    return res.status(400).json({ success: false, message: 'داده نامعتبر' });
  }
  
  const allowedKeys = [
    'site_name', 'site_logo', 'telegram_support', 'telegram_channel', 'telegram_group',
    'transaction_expiry_minutes', 'max_daily_transactions', 'email_notifications',
    'telegram_notifications', 'maintenance_mode', 'auto_reject_hours'
  ];
  
  for (const [key, value] of Object.entries(settings)) {
    if (allowedKeys.includes(key)) {
      setSetting(key, String(value), req.user.id);
    }
  }
  
  auditLog(req.user.id, 'update_settings', 'settings', 'global', null, settings, req.ip, req.headers['user-agent']);
  res.json({ success: true, message: 'تنظیمات با موفقیت ذخیره شد' });
});

// ==================== TRANSACTIONS (OWNER VIEW) ====================
router.get('/transactions', (req, res) => {
  const { page = 1, limit = 20, status, search, dateFrom, dateTo } = req.query;
  const offset = (parseInt(page) - 1) * parseInt(limit);
  
  let where = '1=1';
  const params = [];
  
  if (status) { where += ' AND t.status = ?'; params.push(status); }
  if (search) { 
    where += ' AND (t.tracking_code LIKE ? OR t.customer_email LIKE ? OR t.customer_name LIKE ?)';
    params.push(`%${search}%`, `%${search}%`, `%${search}%`);
  }
  if (dateFrom) { where += ' AND date(t.created_at) >= ?'; params.push(dateFrom); }
  if (dateTo) { where += ' AND date(t.created_at) <= ?'; params.push(dateTo); }
  
  const total = db.prepare(`SELECT COUNT(*) as c FROM transactions t WHERE ${where}`).get(...params).c;
  const transactions = db.prepare(`
    SELECT t.*, bc.card_holder, bc.bank_name, bc.card_number,
           u.username as reviewer_name
    FROM transactions t 
    LEFT JOIN bank_cards bc ON t.card_id = bc.id
    LEFT JOIN users u ON t.reviewed_by = u.id
    WHERE ${where}
    ORDER BY t.created_at DESC
    LIMIT ? OFFSET ?
  `).all(...params, parseInt(limit), offset);
  
  res.json({ success: true, transactions, total, page: parseInt(page), limit: parseInt(limit) });
});

// ==================== AUDIT LOGS ====================
router.get('/audit-logs', (req, res) => {
  const { page = 1, limit = 50 } = req.query;
  const offset = (parseInt(page) - 1) * parseInt(limit);
  
  const total = db.prepare('SELECT COUNT(*) as c FROM audit_logs').get().c;
  const logs = db.prepare(`
    SELECT al.*, u.username, u.full_name
    FROM audit_logs al
    LEFT JOIN users u ON al.user_id = u.id
    ORDER BY al.created_at DESC
    LIMIT ? OFFSET ?
  `).all(parseInt(limit), offset);
  
  res.json({ success: true, logs, total });
});

// ==================== SECURITY EVENTS ====================
router.get('/security-events', (req, res) => {
  const events = db.prepare(`
    SELECT * FROM security_events 
    ORDER BY created_at DESC LIMIT 100
  `).all();
  res.json({ success: true, events });
});

// ==================== REPORTS ====================
router.get('/reports', (req, res) => {
  const { period = '30' } = req.query;
  
  const safePeriod = Math.min(Math.max(parseInt(period) || 30, 1), 365);
  const dailyStats = db.prepare(`
    SELECT 
      date(created_at) as date,
      COUNT(*) as total,
      SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved,
      SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected,
      COALESCE(SUM(CASE WHEN status = 'approved' THEN amount ELSE 0 END), 0) as revenue
    FROM transactions
    WHERE created_at >= date('now', '-' || ? || ' days')
    GROUP BY date(created_at)
    ORDER BY date ASC
  `).all(safePeriod);
  
  const byGateway = db.prepare(`
    SELECT payment_method, COUNT(*) as count, COALESCE(SUM(amount),0) as total
    FROM transactions WHERE status = 'approved'
    GROUP BY payment_method
  `).all();
  
  const topAmounts = db.prepare(`
    SELECT amount, COUNT(*) as count
    FROM transactions WHERE status = 'approved'
    GROUP BY amount ORDER BY count DESC LIMIT 5
  `).all();
  
  res.json({ success: true, dailyStats, byGateway, topAmounts });
});

// ==================== NOTIFICATIONS ====================
router.get('/notifications', (req, res) => {
  const notifications = db.prepare(`
    SELECT * FROM notifications 
    WHERE user_id = ? OR user_id IS NULL
    ORDER BY created_at DESC LIMIT 50
  `).all(req.user.id);
  
  const unread = db.prepare(`
    SELECT COUNT(*) as c FROM notifications 
    WHERE (user_id = ? OR user_id IS NULL) AND is_read = 0
  `).get(req.user.id).c;
  
  res.json({ success: true, notifications, unread });
});

router.post('/notifications/read-all', (req, res) => {
  db.prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ? OR user_id IS NULL").run(req.user.id);
  res.json({ success: true });
});

module.exports = router;
