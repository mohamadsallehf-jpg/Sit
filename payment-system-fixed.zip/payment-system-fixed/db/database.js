// db/database.js - Enterprise Database Layer
const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');

const DB_PATH = process.env.DB_PATH || './db/database.sqlite';

// Ensure directory exists
const dbDir = path.dirname(DB_PATH);
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

const db = new Database(DB_PATH, {
  verbose: process.env.NODE_ENV === 'development' ? console.log : null
});

// Enable WAL mode for better performance
db.pragma('journal_mode = WAL');
db.pragma('synchronous = NORMAL');
db.pragma('foreign_keys = ON');
db.pragma('cache_size = -64000'); // 64MB cache

// ==================== SCHEMA ====================
db.exec(`
  -- Users table
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    role TEXT NOT NULL DEFAULT 'owner' CHECK(role IN ('owner', 'admin')),
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    full_name TEXT,
    email TEXT,
    telegram_id TEXT,
    permissions TEXT DEFAULT '{}',
    is_active INTEGER DEFAULT 1,
    last_login TEXT,
    login_attempts INTEGER DEFAULT 0,
    locked_until TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
  );

  -- Bank Cards table
  CREATE TABLE IF NOT EXISTS bank_cards (
    id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    card_number TEXT NOT NULL,
    card_holder TEXT NOT NULL,
    bank_name TEXT NOT NULL,
    sheba TEXT,
    is_active INTEGER DEFAULT 1,
    display_order INTEGER DEFAULT 0,
    daily_limit INTEGER DEFAULT 0,
    note TEXT,
    created_by TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (created_by) REFERENCES users(id)
  );

  -- Transactions table
  CREATE TABLE IF NOT EXISTS transactions (
    id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    tracking_code TEXT UNIQUE NOT NULL,
    customer_name TEXT,
    customer_email TEXT NOT NULL,
    customer_phone TEXT,
    amount INTEGER NOT NULL,
    description TEXT,
    card_id TEXT,
    payment_method TEXT DEFAULT 'card_to_card' CHECK(payment_method IN ('card_to_card', 'zarinpal', 'idpay', 'vandar')),
    status TEXT DEFAULT 'pending' CHECK(status IN ('pending', 'pending_review', 'approved', 'rejected', 'refunded', 'expired')),
    receipt_image TEXT,
    receipt_uploaded_at TEXT,
    gateway_ref_id TEXT,
    gateway_authority TEXT,
    rejection_reason TEXT,
    approved_by TEXT,
    approved_at TEXT,
    reviewed_by TEXT,
    reviewed_at TEXT,
    ip_address TEXT,
    user_agent TEXT,
    metadata TEXT DEFAULT '{}',
    expires_at TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (card_id) REFERENCES bank_cards(id),
    FOREIGN KEY (approved_by) REFERENCES users(id),
    FOREIGN KEY (reviewed_by) REFERENCES users(id)
  );

  -- Payment Gateways config
  CREATE TABLE IF NOT EXISTS payment_gateways (
    id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    name TEXT UNIQUE NOT NULL,
    display_name TEXT NOT NULL,
    api_key TEXT,
    merchant_id TEXT,
    sandbox INTEGER DEFAULT 1,
    is_active INTEGER DEFAULT 0,
    config TEXT DEFAULT '{}',
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
  );

  -- System Settings
  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT,
    description TEXT,
    updated_by TEXT,
    updated_at TEXT DEFAULT (datetime('now'))
  );

  -- Audit Log
  CREATE TABLE IF NOT EXISTS audit_logs (
    id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    user_id TEXT,
    action TEXT NOT NULL,
    entity_type TEXT,
    entity_id TEXT,
    old_data TEXT,
    new_data TEXT,
    ip_address TEXT,
    user_agent TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );

  -- Notifications
  CREATE TABLE IF NOT EXISTS notifications (
    id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    user_id TEXT,
    type TEXT NOT NULL,
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    is_read INTEGER DEFAULT 0,
    metadata TEXT DEFAULT '{}',
    created_at TEXT DEFAULT (datetime('now'))
  );

  -- Security Events
  CREATE TABLE IF NOT EXISTS security_events (
    id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    event_type TEXT NOT NULL,
    ip_address TEXT,
    user_agent TEXT,
    details TEXT,
    severity TEXT DEFAULT 'low' CHECK(severity IN ('low', 'medium', 'high', 'critical')),
    created_at TEXT DEFAULT (datetime('now'))
  );

  -- Indexes for performance
  CREATE INDEX IF NOT EXISTS idx_transactions_status ON transactions(status);
  CREATE INDEX IF NOT EXISTS idx_transactions_email ON transactions(customer_email);
  CREATE INDEX IF NOT EXISTS idx_transactions_created ON transactions(created_at);
  CREATE INDEX IF NOT EXISTS idx_transactions_tracking ON transactions(tracking_code);
  CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_logs(user_id);
  CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at);
  CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, is_read);
  CREATE INDEX IF NOT EXISTS idx_security_events ON security_events(event_type, created_at);
`);

// ==================== SEED DEFAULT DATA ====================
async function seedDefaults() {
  // Create owner if not exists
  const ownerUsername = process.env.OWNER_USERNAME || 'admin';
  const ownerPassword = process.env.OWNER_PASSWORD || 'Admin@1234';
  
  const existingOwner = db.prepare('SELECT id FROM users WHERE role = ?').get('owner');
  if (!existingOwner) {
    const hashedPassword = await bcrypt.hash(ownerPassword, 12);
    db.prepare(`
      INSERT INTO users (role, username, password, full_name, email, permissions)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run('owner', ownerUsername, hashedPassword, 'مالک سیستم', '', JSON.stringify({ all: true }));
    console.log('✅ Owner account created:', ownerUsername);
  }

  // Default gateways
  const gateways = [
    { name: 'zarinpal', display_name: 'زرین پال', config: JSON.stringify({ callback_url: '/api/payment/zarinpal/verify' }) },
    { name: 'idpay', display_name: 'آیدی پی', config: JSON.stringify({ callback_url: '/api/payment/idpay/verify' }) },
    { name: 'vandar', display_name: 'وندار', config: JSON.stringify({ callback_url: '/api/payment/vandar/verify' }) }
  ];
  
  for (const gw of gateways) {
    const exists = db.prepare('SELECT id FROM payment_gateways WHERE name = ?').get(gw.name);
    if (!exists) {
      db.prepare(`INSERT INTO payment_gateways (name, display_name, config) VALUES (?, ?, ?)`)
        .run(gw.name, gw.display_name, gw.config);
    }
  }

  // Default settings
  const defaultSettings = [
    { key: 'site_name', value: 'سیستم پرداخت صالح', description: 'نام سایت' },
    { key: 'site_logo', value: '', description: 'آدرس لوگو' },
    { key: 'telegram_support', value: '@Onicor', description: 'آیدی تلگرام پشتیبانی' },
    { key: 'telegram_channel', value: '@codmmd_ch', description: 'آیدی کانال تلگرام' },
    { key: 'telegram_group', value: '@codmmd_gp', description: 'آیدی گروه تلگرام' },
    { key: 'transaction_expiry_minutes', value: '60', description: 'مدت انقضای تراکنش (دقیقه)' },
    { key: 'max_daily_transactions', value: '100', description: 'حداکثر تراکنش روزانه' },
    { key: 'email_notifications', value: 'true', description: 'ارسال ایمیل' },
    { key: 'telegram_notifications', value: 'true', description: 'نوتیفیکیشن تلگرام' },
    { key: 'maintenance_mode', value: 'false', description: 'حالت تعمیرات' },
    { key: 'auto_reject_hours', value: '24', description: 'رد خودکار رسید بعد از (ساعت)' }
  ];

  for (const s of defaultSettings) {
    const exists = db.prepare('SELECT key FROM settings WHERE key = ?').get(s.key);
    if (!exists) {
      db.prepare('INSERT INTO settings (key, value, description) VALUES (?, ?, ?)').run(s.key, s.value, s.description);
    }
  }

  console.log('✅ Database initialized successfully');
}

// Helper functions
const dbHelpers = {
  getSetting: (key) => {
    const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key);
    return row ? row.value : null;
  },
  
  setSetting: (key, value, userId = null) => {
    db.prepare(`
      INSERT INTO settings (key, value, updated_by, updated_at) VALUES (?, ?, ?, datetime('now'))
      ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_by = excluded.updated_by, updated_at = excluded.updated_at
    `).run(key, value, userId);
  },
  
  auditLog: (userId, action, entityType, entityId, oldData, newData, ip, ua) => {
    db.prepare(`
      INSERT INTO audit_logs (user_id, action, entity_type, entity_id, old_data, new_data, ip_address, user_agent)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(userId, action, entityType, entityId, 
      oldData ? JSON.stringify(oldData) : null,
      newData ? JSON.stringify(newData) : null,
      ip, ua);
  },
  
  addNotification: (userId, type, title, message, metadata = {}) => {
    db.prepare(`
      INSERT INTO notifications (user_id, type, title, message, metadata)
      VALUES (?, ?, ?, ?, ?)
    `).run(userId, type, title, message, JSON.stringify(metadata));
  },
  
  logSecurityEvent: (eventType, ip, ua, details, severity = 'low') => {
    db.prepare(`
      INSERT INTO security_events (event_type, ip_address, user_agent, details, severity)
      VALUES (?, ?, ?, ?, ?)
    `).run(eventType, ip, ua, typeof details === 'object' ? JSON.stringify(details) : details, severity);
  },

  generateTrackingCode: () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let code = 'PAY-';
    for (let i = 0; i < 8; i++) code += chars[Math.floor(Math.random() * chars.length)];
    return code;
  }
};

module.exports = { db, seedDefaults, ...dbHelpers };
