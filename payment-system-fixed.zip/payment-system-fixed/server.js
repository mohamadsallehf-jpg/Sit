// server.js - Enterprise Payment System Main Server
// Developed by Saleh @Onicor | @codmmd_ch | @codmmd_gp
require('dotenv').config();

const express = require('express');
const path = require('path');
const cors = require('cors');
const compression = require('compression');
const morgan = require('morgan');
const winston = require('winston');
const fs = require('fs');

const { seedDefaults } = require('./db/database');
const { helmetConfig, requestInspector, ipFilter, speedLimiter, apiLimiter, maintenanceCheck } = require('./middleware/security');
const { initBot } = require('./services/telegram');
const { initTransporter } = require('./services/email');

// ==================== LOGGER ====================
const logDir = path.join(__dirname, 'logs');
if (!fs.existsSync(logDir)) fs.mkdirSync(logDir);

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  transports: [
    new winston.transports.File({ filename: path.join(logDir, 'error.log'), level: 'error', maxsize: 10485760, maxFiles: 5 }),
    new winston.transports.File({ filename: path.join(logDir, 'combined.log'), maxsize: 10485760, maxFiles: 10 }),
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.colorize(),
        winston.format.simple()
      )
    })
  ]
});

// ==================== APP SETUP ====================
const app = express();

// Trust proxy for accurate IPs (when behind nginx)
app.set('trust proxy', 1);

// Security headers
app.use(helmetConfig);

// CORS
const allowedOrigins = (process.env.ALLOWED_ORIGINS || '').split(',').filter(Boolean);
app.use(cors({
  origin: (origin, callback) => {
    if (!origin || allowedOrigins.length === 0 || allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error('CORS policy violation'));
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// Compression
app.use(compression());

// Body parsing with limits
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: false, limit: '10kb' }));

// Logging
app.use(morgan('combined', {
  stream: { write: (msg) => logger.info(msg.trim()) }
}));

// Security middleware
app.use(ipFilter);
app.use(requestInspector);
app.use(speedLimiter);
app.use(maintenanceCheck);

// Static files (receipts)
app.use('/uploads', express.static(path.join(__dirname, 'public/uploads'), {
  maxAge: '1d',
  setHeaders: (res) => {
    res.set('X-Content-Type-Options', 'nosniff');
    res.set('Content-Disposition', 'inline');
  }
}));

// ==================== ROUTES ====================
app.use('/api/auth', require('./routes/auth'));
app.use('/api/payment', require('./routes/payment'));
app.use('/api/owner', require('./routes/owner'));
app.use('/api/admin', require('./routes/admin'));

// Health check
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    version: '2.0.0',
    uptime: process.uptime()
  });
});

// Serve frontend HTML files
const serveHtml = (filePath) => (req, res) => {
  res.sendFile(path.join(__dirname, 'public', filePath));
};

// Pages
app.get('/', serveHtml('index.html'));
app.get('/owner', serveHtml('owner/index.html'));
app.get('/owner/*', serveHtml('owner/index.html'));
app.get('/admin', serveHtml('admin/index.html'));
app.get('/admin/*', serveHtml('admin/index.html'));

// 404
app.use((req, res) => {
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ success: false, message: 'مسیر یافت نشد' });
  }
  res.status(404).sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Global error handler
app.use((err, req, res, next) => {
  logger.error('Unhandled error:', { error: err.message, stack: err.stack, path: req.path });
  
  if (err.message === 'CORS policy violation') {
    return res.status(403).json({ success: false, message: 'درخواست غیرمجاز' });
  }
  
  res.status(500).json({ success: false, message: 'خطای سرور. لطفاً دوباره تلاش کنید.' });
});

// ==================== AUTO CLEANUP JOB ====================
const runCleanup = () => {
  const { db, getSetting } = require('./db/database');
  
  // Auto-expire old transactions
  const expiredResult = db.prepare(`
    UPDATE transactions SET status = 'expired', updated_at = datetime('now')
    WHERE status = 'pending' AND expires_at < datetime('now')
  `).run();
  
  if (expiredResult.changes > 0) {
    logger.info(`Auto-expired ${expiredResult.changes} transactions`);
  }
  
  // Auto-reject old pending_review
  const autoRejectHours = parseInt(getSetting('auto_reject_hours') || '24');
  const autoRejected = db.prepare(`
    UPDATE transactions SET status = 'rejected', rejection_reason = 'رد خودکار - مهلت بررسی منقضی شد', updated_at = datetime('now')
    WHERE status = 'pending_review' AND receipt_uploaded_at < datetime('now', ?)
  `).run(`-${autoRejectHours} hours`);
  
  if (autoRejected.changes > 0) {
    logger.info(`Auto-rejected ${autoRejected.changes} unreviewed receipts`);
  }
  
  // Clean old audit logs (keep 90 days)
  db.prepare("DELETE FROM audit_logs WHERE created_at < datetime('now', '-90 days')").run();
  
  // Clean old security events (keep 30 days)
  db.prepare("DELETE FROM security_events WHERE created_at < datetime('now', '-30 days')").run();
};

// Run cleanup every hour
setInterval(runCleanup, 60 * 60 * 1000);

// ==================== START ====================
const PORT = process.env.PORT || 3000;

const startServer = async () => {
  try {
    // Initialize database
    await seedDefaults();
    
    // Initialize services
    initBot();
    initTransporter();
    
    // Run initial cleanup
    setTimeout(runCleanup, 5000);
    
    app.listen(PORT, '0.0.0.0', () => {
      console.log('\n' + '='.repeat(60));
      console.log('🚀 Payment System Server Started!');
      console.log('='.repeat(60));
      console.log(`📡 Port: ${PORT}`);
      console.log(`🌍 Environment: ${process.env.NODE_ENV || 'development'}`);
      console.log(`💳 Main Page: http://localhost:${PORT}`);
      console.log(`👑 Owner Panel: http://localhost:${PORT}/owner`);
      console.log(`👤 Admin Panel: http://localhost:${PORT}/admin`);
      console.log(`🔑 Owner Login: ${process.env.OWNER_USERNAME || 'saleh'}`);
      console.log('='.repeat(60));
      console.log('✅ System ready! Developed by Saleh @Onicor');
      console.log('='.repeat(60) + '\n');
    });
    
  } catch (err) {
    logger.error('Failed to start server:', err);
    process.exit(1);
  }
};

// Graceful shutdown
process.on('SIGTERM', () => {
  logger.info('SIGTERM received. Shutting down gracefully...');
  process.exit(0);
});

process.on('uncaughtException', (err) => {
  logger.error('Uncaught Exception:', err);
  process.exit(1);
});

process.on('unhandledRejection', (reason) => {
  logger.error('Unhandled Rejection:', reason);
});

startServer();
