// services/telegram.js - Telegram Bot Service
let bot;

const initBot = () => {
  if (!process.env.TELEGRAM_BOT_TOKEN) {
    console.log('⚠️  Telegram bot token not set, notifications disabled');
    return null;
  }
  
  try {
    const TelegramBot = require('node-telegram-bot-api');
    bot = new TelegramBot(process.env.TELEGRAM_BOT_TOKEN, { polling: false });
    console.log('✅ Telegram bot initialized');
    return bot;
  } catch (err) {
    console.error('❌ Telegram bot init error:', err.message);
    return null;
  }
};

const sendMessage = async (chatId, message, options = {}) => {
  if (!bot) return;
  try {
    await bot.sendMessage(chatId, message, { parse_mode: 'HTML', ...options });
    return true;
  } catch (err) {
    console.error('❌ Telegram send error:', err.message);
    return false;
  }
};

const sendPhoto = async (chatId, photoPath, caption) => {
  if (!bot) return;
  try {
    const fs = require('fs');
    if (!fs.existsSync(photoPath)) return false;
    await bot.sendPhoto(chatId, fs.createReadStream(photoPath), { caption, parse_mode: 'HTML' });
    return true;
  } catch (err) {
    console.error('❌ Telegram sendPhoto error:', err.message);
    return false;
  }
};

// ==================== NOTIFICATION TEMPLATES ====================

const notifications = {
  
  newReceipt: async (transaction) => {
    const chatId = process.env.TELEGRAM_OWNER_CHAT_ID;
    if (!chatId) return;
    
    const msg = `
🔔 <b>رسید جدید دریافت شد!</b>

🔖 کد رهگیری: <code>${transaction.trackingCode}</code>
💰 مبلغ: <b>${transaction.amount?.toLocaleString('fa-IR')} تومان</b>
👤 نام: ${transaction.customerName || 'نامشخص'}
📧 ایمیل: ${transaction.customerEmail}
🕐 زمان: ${new Date().toLocaleString('fa-IR')}

⚡ برای بررسی وارد پنل مالک شوید.
    `;
    
    await sendMessage(chatId, msg);
    
    // Send receipt image if exists
    if (transaction.receiptImage) {
      const path = require('path');
      const imagePath = path.join(__dirname, '../public', transaction.receiptImage);
      await sendPhoto(chatId, imagePath, `📎 رسید تراکنش: ${transaction.trackingCode}`);
    }
  },
  
  receiptApproved: async (transaction) => {
    const chatId = process.env.TELEGRAM_OWNER_CHAT_ID;
    if (!chatId) return;
    
    const msg = `
✅ <b>رسید تأیید شد</b>

🔖 کد: <code>${transaction.trackingCode}</code>
💰 مبلغ: <b>${transaction.amount?.toLocaleString('fa-IR')} تومان</b>
📧 ایمیل: ${transaction.customerEmail}
👤 تأیید کننده: ${transaction.approvedBy || 'سیستم'}
🕐 زمان: ${new Date().toLocaleString('fa-IR')}
    `;
    
    await sendMessage(chatId, msg);
  },
  
  receiptRejected: async (transaction) => {
    const chatId = process.env.TELEGRAM_OWNER_CHAT_ID;
    if (!chatId) return;
    
    const msg = `
❌ <b>رسید رد شد</b>

🔖 کد: <code>${transaction.trackingCode}</code>
💰 مبلغ: <b>${transaction.amount?.toLocaleString('fa-IR')} تومان</b>
📧 ایمیل: ${transaction.customerEmail}
📝 دلیل: ${transaction.rejectionReason || 'ذکر نشده'}
🕐 زمان: ${new Date().toLocaleString('fa-IR')}
    `;
    
    await sendMessage(chatId, msg);
  },
  
  newAdmin: async (adminData) => {
    const chatId = process.env.TELEGRAM_OWNER_CHAT_ID;
    if (!chatId) return;
    
    const msg = `
👤 <b>ادمین جدید اضافه شد</b>

📛 نام: ${adminData.fullName}
🔑 نام کاربری: <code>${adminData.username}</code>
🕐 زمان: ${new Date().toLocaleString('fa-IR')}
    `;
    
    await sendMessage(chatId, msg);
  },
  
  systemAlert: async (message, severity = 'info') => {
    const chatId = process.env.TELEGRAM_OWNER_CHAT_ID;
    if (!chatId) return;
    
    const icons = { info: 'ℹ️', warning: '⚠️', error: '🚨', success: '✅' };
    const msg = `${icons[severity] || 'ℹ️'} <b>هشدار سیستم</b>\n\n${message}`;
    await sendMessage(chatId, msg);
  }
};

module.exports = { initBot, sendMessage, sendPhoto, notifications };
