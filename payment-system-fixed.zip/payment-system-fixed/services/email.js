// services/email.js - Professional Email Service
const nodemailer = require('nodemailer');
const { getSetting } = require('../db/database');

let transporter;

const initTransporter = () => {
  transporter = nodemailer.createTransport({
    host: process.env.EMAIL_HOST,
    port: parseInt(process.env.EMAIL_PORT) || 587,
    secure: process.env.EMAIL_SECURE === 'true',
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS
    },
    pool: true,
    maxConnections: 5,
    maxMessages: 100,
    rateDelta: 1000,
    rateLimit: 5
  });
};

const getBaseTemplate = (content, title) => {
  const siteName = getSetting('site_name') || 'سیستم پرداخت';
  return `
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${title}</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Vazir:wght@300;400;500;600;700&display=swap');
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: 'Vazir', Tahoma, Arial, sans-serif;
      background: linear-gradient(135deg, #0f0f23 0%, #1e1b4b 100%);
      direction: rtl;
      min-height: 100vh;
      padding: 40px 20px;
    }
    .email-wrapper {
      max-width: 600px;
      margin: 0 auto;
    }
    .email-header {
      background: linear-gradient(135deg, #4f46e5, #7c3aed);
      border-radius: 20px 20px 0 0;
      padding: 40px 30px;
      text-align: center;
    }
    .logo-area {
      width: 70px;
      height: 70px;
      background: rgba(255,255,255,0.2);
      border-radius: 20px;
      margin: 0 auto 20px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 32px;
    }
    .email-header h1 {
      color: white;
      font-size: 24px;
      font-weight: 700;
      margin-bottom: 8px;
    }
    .email-header p {
      color: rgba(255,255,255,0.8);
      font-size: 14px;
    }
    .email-body {
      background: white;
      padding: 40px 30px;
    }
    .status-badge {
      display: inline-block;
      padding: 10px 24px;
      border-radius: 50px;
      font-size: 16px;
      font-weight: 600;
      margin: 20px 0;
    }
    .status-approved {
      background: linear-gradient(135deg, #10b981, #059669);
      color: white;
    }
    .status-rejected {
      background: linear-gradient(135deg, #ef4444, #dc2626);
      color: white;
    }
    .info-card {
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 12px;
      padding: 20px;
      margin: 20px 0;
    }
    .info-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 10px 0;
      border-bottom: 1px solid #e2e8f0;
      font-size: 14px;
    }
    .info-row:last-child { border-bottom: none; }
    .info-label { color: #64748b; }
    .info-value { color: #1e293b; font-weight: 600; }
    .message-box {
      border-right: 4px solid #4f46e5;
      padding: 15px 20px;
      background: #f0f4ff;
      border-radius: 0 12px 12px 0;
      margin: 20px 0;
      font-size: 14px;
      line-height: 1.8;
      color: #334155;
    }
    .cta-button {
      display: inline-block;
      background: linear-gradient(135deg, #4f46e5, #7c3aed);
      color: white !important;
      text-decoration: none;
      padding: 14px 32px;
      border-radius: 12px;
      font-size: 15px;
      font-weight: 600;
      margin: 20px 0;
    }
    .telegram-box {
      background: linear-gradient(135deg, #0088cc, #006699);
      border-radius: 12px;
      padding: 20px;
      margin: 20px 0;
      color: white;
      text-align: center;
    }
    .telegram-box p { font-size: 14px; margin-bottom: 10px; opacity: 0.9; }
    .telegram-link {
      color: white !important;
      font-weight: 700;
      font-size: 16px;
      text-decoration: none;
    }
    .email-footer {
      background: #1e1b4b;
      border-radius: 0 0 20px 20px;
      padding: 25px 30px;
      text-align: center;
    }
    .email-footer p {
      color: rgba(255,255,255,0.5);
      font-size: 12px;
      line-height: 1.8;
    }
    .divider {
      border: none;
      height: 1px;
      background: linear-gradient(to right, transparent, #e2e8f0, transparent);
      margin: 20px 0;
    }
  </style>
</head>
<body>
  <div class="email-wrapper">
    <div class="email-header">
      <div class="logo-area">💳</div>
      <h1>${siteName}</h1>
      <p>سیستم مدیریت پرداخت هوشمند</p>
    </div>
    <div class="email-body">
      ${content}
    </div>
    <div class="email-footer">
      <p>این ایمیل به صورت خودکار ارسال شده است. لطفاً به آن پاسخ ندهید.</p>
      <p>© ${new Date().getFullYear()} ${siteName} | توسعه یافته توسط صالح @Onicor</p>
    </div>
  </div>
</body>
</html>
  `;
};

// ==================== EMAIL TEMPLATES ====================

const emailTemplates = {
  
  receiptApproved: (data) => {
    const siteName = getSetting('site_name') || 'سیستم پرداخت';
    const telegramSupport = getSetting('telegram_support') || '@Onicor';
    const content = `
      <h2 style="color: #1e293b; font-size: 20px; margin-bottom: 8px;">سلام، ${data.customerName || 'کاربر گرامی'} 👋</h2>
      <p style="color: #64748b; font-size: 14px; margin-bottom: 20px;">رسید پرداخت شما با موفقیت بررسی و تأیید شد.</p>
      
      <div style="text-align: center;">
        <span class="status-badge status-approved">✅ رسید تأیید شد</span>
      </div>
      
      <div class="message-box">
        <strong style="color: #4f46e5;">پیام مدیریت:</strong><br>
        پرداخت شما با مبلغ <strong>${data.amount?.toLocaleString('fa-IR')} تومان</strong> دریافت و تأیید گردید. 
        سفارش شما در اسرع وقت پردازش خواهد شد. از اعتماد شما صمیمانه سپاسگزاریم.
      </div>
      
      <div class="info-card">
        <div class="info-row">
          <span class="info-label">🔖 کد رهگیری</span>
          <span class="info-value" style="font-family: monospace;">${data.trackingCode}</span>
        </div>
        <div class="info-row">
          <span class="info-label">💰 مبلغ پرداختی</span>
          <span class="info-value" style="color: #10b981;">${data.amount?.toLocaleString('fa-IR')} تومان</span>
        </div>
        <div class="info-row">
          <span class="info-label">📅 تاریخ تأیید</span>
          <span class="info-value">${data.approvedAt}</span>
        </div>
        <div class="info-row">
          <span class="info-label">📧 ایمیل</span>
          <span class="info-value">${data.customerEmail}</span>
        </div>
      </div>
      
      <p style="font-size: 13px; color: #64748b; line-height: 1.8; margin: 15px 0;">
        🔐 کد رهگیری <strong style="color: #4f46e5;">${data.trackingCode}</strong> را نزد خود نگه دارید. 
        در صورت نیاز به پیگیری، این کد را در اختیار پشتیبانی قرار دهید.
      </p>
      
      <div class="telegram-box">
        <p>📱 برای پیگیری سفارش با ما در ارتباط باشید</p>
        <a href="https://t.me/${telegramSupport.replace('@', '')}" class="telegram-link">
          تلگرام پشتیبانی: ${telegramSupport}
        </a>
      </div>
    `;
    
    return {
      subject: `✅ رسید شما تأیید شد | کد: ${data.trackingCode}`,
      html: getBaseTemplate(content, 'تأیید رسید پرداخت')
    };
  },
  
  receiptRejected: (data) => {
    const siteName = getSetting('site_name') || 'سیستم پرداخت';
    const telegramSupport = getSetting('telegram_support') || '@Onicor';
    const content = `
      <h2 style="color: #1e293b; font-size: 20px; margin-bottom: 8px;">سلام، ${data.customerName || 'کاربر گرامی'} 👋</h2>
      <p style="color: #64748b; font-size: 14px; margin-bottom: 20px;">متأسفانه رسید پرداخت ارسالی شما تأیید نشد.</p>
      
      <div style="text-align: center;">
        <span class="status-badge status-rejected">❌ رسید رد شد</span>
      </div>
      
      <div class="info-card" style="border-color: #fecaca;">
        <div class="info-row">
          <span class="info-label">🔖 کد رهگیری</span>
          <span class="info-value" style="font-family: monospace;">${data.trackingCode}</span>
        </div>
        <div class="info-row">
          <span class="info-label">💰 مبلغ</span>
          <span class="info-value">${data.amount?.toLocaleString('fa-IR')} تومان</span>
        </div>
        <div class="info-row">
          <span class="info-label">📅 تاریخ رد</span>
          <span class="info-value">${data.rejectedAt}</span>
        </div>
      </div>
      
      ${data.rejectionReason ? `
      <div class="message-box" style="border-color: #ef4444; background: #fff5f5;">
        <strong style="color: #ef4444;">دلیل رد:</strong><br>
        ${data.rejectionReason}
      </div>
      ` : ''}
      
      <div style="background: #fffbeb; border: 1px solid #fde68a; border-radius: 12px; padding: 20px; margin: 20px 0;">
        <h4 style="color: #92400e; margin-bottom: 12px;">📌 مراحل بعدی:</h4>
        <ul style="color: #78350f; font-size: 14px; line-height: 2; list-style: none;">
          <li>۱. بررسی مجدد رسید واریز</li>
          <li>۲. مطمئن شوید مبلغ و شماره کارت صحیح است</li>
          <li>۳. رسید واضح و خوانا ارسال کنید</li>
          <li>۴. در صورت اطمینان از پرداخت، با پشتیبانی تماس بگیرید</li>
        </ul>
      </div>
      
      <div class="telegram-box">
        <p>📱 برای رفع مشکل با پشتیبانی ما در تماس باشید</p>
        <a href="https://t.me/${telegramSupport.replace('@', '')}" class="telegram-link">
          ${telegramSupport} - پشتیبانی ۲۴/۷
        </a>
      </div>
      
      <p style="font-size: 12px; color: #94a3b8; text-align: center; margin-top: 20px;">
        در صورت واریز اشتباهی، مبلغ ظرف ۷۲ ساعت کاری به حساب شما برگشت داده خواهد شد.
      </p>
    `;
    
    return {
      subject: `❌ رسید شما رد شد | کد: ${data.trackingCode}`,
      html: getBaseTemplate(content, 'رد رسید پرداخت')
    };
  }
};

// ==================== SEND EMAIL ====================
const sendEmail = async (to, template) => {
  if (!transporter) initTransporter();
  
  try {
    const info = await transporter.sendMail({
      from: `"${process.env.EMAIL_FROM_NAME || 'سیستم پرداخت'}" <${process.env.EMAIL_FROM}>`,
      to,
      subject: template.subject,
      html: template.html
    });
    
    console.log('✅ Email sent:', info.messageId, 'to:', to);
    return { success: true, messageId: info.messageId };
  } catch (error) {
    console.error('❌ Email error:', error.message);
    return { success: false, error: error.message };
  }
};

module.exports = { sendEmail, emailTemplates, initTransporter };
