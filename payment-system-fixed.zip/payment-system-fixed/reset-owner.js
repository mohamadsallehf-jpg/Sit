/**
 * reset-owner.js - اجرا کن اگر مالک قفل شده یا رمز فراموش شده
 * دستور اجرا: node reset-owner.js
 */
require('dotenv').config();
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const path = require('path');

const DB_PATH = process.env.DB_PATH || './db/database.sqlite';

async function resetOwner() {
  console.log('🔄 در حال ریست کردن حساب مالک...');
  
  const db = new Database(DB_PATH);
  
  const newUsername = process.env.OWNER_USERNAME || 'admin';
  const newPassword = process.env.OWNER_PASSWORD || 'Admin@1234';
  
  const hashedPassword = await bcrypt.hash(newPassword, 12);
  
  // Check if owner exists
  const owner = db.prepare("SELECT id FROM users WHERE role = 'owner'").get();
  
  if (owner) {
    // Reset existing owner
    db.prepare(`
      UPDATE users SET 
        username = ?,
        password = ?,
        login_attempts = 0,
        locked_until = NULL,
        is_active = 1,
        updated_at = datetime('now')
      WHERE role = 'owner'
    `).run(newUsername, hashedPassword);
    console.log('✅ حساب مالک ریست شد');
  } else {
    // Create new owner
    db.prepare(`
      INSERT INTO users (role, username, password, full_name, permissions)
      VALUES ('owner', ?, ?, 'مالک سیستم', '{"all":true}')
    `).run(newUsername, hashedPassword);
    console.log('✅ حساب مالک ایجاد شد');
  }
  
  console.log(`👤 نام کاربری: ${newUsername}`);
  console.log(`🔑 رمز عبور: ${newPassword}`);
  console.log('⚠️ لطفاً بعد از ورود رمز را تغییر دهید!');
  
  db.close();
}

resetOwner().catch(console.error);
