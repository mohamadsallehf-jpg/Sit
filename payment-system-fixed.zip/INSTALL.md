# 🚀 راهنمای نصب کامل سیستم پرداخت
## توسعه‌دهنده: صالح | @Onicor | @codmmd_ch

---

## 📋 پیش‌نیازها
- Ubuntu 24 LTS
- دامنه با رکورد A که به IP سرور اشاره دارد

---

## 🔧 مرحله ۱: آماده‌سازی سرور

```bash
# آپدیت سرور
sudo apt update && sudo apt upgrade -y

# نصب ابزارهای پایه
sudo apt install -y curl wget git build-essential

# نصب Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
node --version   # باید v20.x.x باشد
npm --version

# نصب PM2 (مدیر پروسه)
sudo npm install -g pm2

# نصب Nginx
sudo apt install -y nginx

# نصب Certbot (SSL رایگان)
sudo apt install -y certbot python3-certbot-nginx
```

---

## 📁 مرحله ۲: آپلود فایل‌ها

```bash
# ساخت پوشه
sudo mkdir -p /var/www/payment-system
sudo chown -R $USER:$USER /var/www/payment-system

# روش ۱: آپلود با SCP از کامپیوتر خودتان
# scp -r payment-system.zip user@YOUR_IP:/var/www/

# روش ۲: از سرور مستقیم
cd /var/www
# فایل zip را آپلود کنید، سپس:
unzip payment-system.zip
cd payment-system
```

---

## ⚙️ مرحله ۳: تنظیم Environment

```bash
cd /var/www/payment-system

# کپی فایل env
cp .env.example .env

# ویرایش با nano
nano .env
```

### 📝 تنظیمات مهم در .env:

```
# آدرس سایت شما
BASE_URL=https://yourdomain.com

# JWT - حتماً عوض کنید!
JWT_SECRET=یک رشته تصادفی طولانی اینجا بذارید

# اطلاعات مالک
OWNER_USERNAME=saleh
OWNER_PASSWORD=saleh_1388

# ایمیل (Gmail با App Password)
EMAIL_USER=your@gmail.com
EMAIL_PASS=xxxx xxxx xxxx xxxx

# تلگرام (اختیاری)
TELEGRAM_BOT_TOKEN=123456:ABC-DEF...
TELEGRAM_OWNER_CHAT_ID=123456789

# دامنه مجاز
ALLOWED_ORIGINS=https://yourdomain.com
```

**نحوه گرفتن Gmail App Password:**
1. Google Account → Security → 2-Step Verification (فعال کنید)
2. App Passwords → Generate
3. رمز ۱۶ کاراکتری را در EMAIL_PASS بگذارید

**نحوه گرفتن Telegram Bot Token:**
1. به @BotFather در تلگرام پیام بدید
2. /newbot → اسم ربات → یوزرنیم ربات
3. توکن را کپی کنید

**نحوه گرفتن Chat ID:**
1. ربات خود را باز کنید و /start بزنید
2. این URL را در مرورگر باز کنید: https://api.telegram.org/botTOKEN/getUpdates
3. chat.id را کپی کنید

---

## 📦 مرحله ۴: نصب Dependencies

```bash
cd /var/www/payment-system

# نصب پکیج‌ها
npm install --production

# تست سرور
node server.js
# اگر خطا نداشت Ctrl+C بزنید
```

---

## 🌐 مرحله ۵: تنظیم Nginx

```bash
# کپی config
sudo cp /var/www/payment-system/nginx.conf /etc/nginx/sites-available/payment-system

# ویرایش: yourdomain.com را با دامنه خود عوض کنید
sudo nano /etc/nginx/sites-available/payment-system

# فعال‌سازی
sudo ln -s /etc/nginx/sites-available/payment-system /etc/nginx/sites-enabled/

# حذف default
sudo rm -f /etc/nginx/sites-enabled/default

# تست
sudo nginx -t

# اگر OK بود:
sudo systemctl restart nginx
sudo systemctl enable nginx
```

---

## 🔒 مرحله ۶: SSL رایگان (Let's Encrypt)

```bash
# دامنه را با Certbot ثبت کنید
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com

# ایمیل وارد کنید، شرایط را قبول کنید، Y بزنید
# تجدید خودکار
sudo certbot renew --dry-run
```

---

## 🚀 مرحله ۷: راه‌اندازی با PM2

```bash
cd /var/www/payment-system

# شروع با PM2
pm2 start ecosystem.config.js

# وضعیت
pm2 status

# لاگ‌ها
pm2 logs payment-system

# اجرای خودکار بعد از ریست سرور
pm2 startup
# دستور نمایش داده شده را اجرا کنید
pm2 save

# بررسی
pm2 status
```

---

## ✅ مرحله ۸: تست نهایی

```bash
# تست API
curl https://yourdomain.com/api/health

# باید چیزی مثل این ببینید:
# {"status":"ok","timestamp":"...","version":"2.0.0"}
```

**صفحات وب:**
- صفحه اصلی: `https://yourdomain.com`
- پنل مالک: `https://yourdomain.com/owner`
- پنل ادمین: `https://yourdomain.com/admin`

**اطلاعات ورود مالک (پیش‌فرض):**
- نام کاربری: `saleh`
- رمز عبور: `saleh_1388`

---

## 🔄 دستورات مفید روزمره

```bash
# مشاهده لاگ‌ها
pm2 logs payment-system --lines 100

# ری‌استارت
pm2 restart payment-system

# استاپ
pm2 stop payment-system

# آپدیت کد (بعد از تغییرات)
cd /var/www/payment-system
# فایل‌های جدید را آپلود کنید
pm2 restart payment-system

# بکاپ دیتابیس
cp /var/www/payment-system/db/database.sqlite /root/backup_$(date +%Y%m%d).sqlite

# وضعیت Nginx
sudo systemctl status nginx

# ری‌استارت Nginx
sudo systemctl restart nginx
```

---

## 🔥 Firewall تنظیم

```bash
sudo ufw allow ssh
sudo ufw allow 80
sudo ufw allow 443
sudo ufw enable
sudo ufw status
```

---

## 📱 استفاده از سیستم

### برای مالک:
1. به `/owner` بروید و با یوزر/پسورد مالک وارد شوید
2. از بخش **کارت‌های بانکی** کارت بانکی اضافه کنید
3. از بخش **درگاه پرداخت** اگر توکن درگاه دارید اضافه کنید
4. از بخش **مدیریت ادمین** ادمین با دسترسی دلخواه بسازید
5. از بخش **بررسی رسیدها** رسید کاربران را تأیید/رد کنید

### برای ادمین:
1. به `/admin` بروید و لاگین کنید
2. رسیدهای در انتظار را مشاهده و بررسی کنید
3. بعد از تأیید/رد، ایمیل خودکار به کاربر ارسال می‌شود

### برای کاربر:
1. اطلاعات را وارد می‌کند
2. شماره کارت نمایش داده می‌شود
3. واریز می‌کند و رسید آپلود می‌کند
4. ایمیل نتیجه دریافت می‌کند

---

## 🛡️ امنیت

سیستم دارای این لایه‌های امنیتی است:
- **Rate Limiting**: محدودیت درخواست برای جلوگیری از DDoS
- **Helmet.js**: هدرهای امنیتی HTTP
- **JWT**: احراز هویت امن با توکن
- **bcrypt**: رمزنگاری قوی پسورد (12 rounds)
- **SQL Injection Protection**: استفاده از Prepared Statements
- **XSS Protection**: پاکسازی ورودی‌ها
- **IP Rate Limiting**: محدودیت بر اساس IP
- **File Type Validation**: اعتبارسنجی نوع فایل آپلودی
- **Account Lockout**: قفل شدن حساب بعد از ۵ بار ورود اشتباه
- **Audit Log**: ثبت تمام فعالیت‌ها
- **Security Events**: ثبت رویدادهای امنیتی مشکوک

---

## ❓ مشکلات رایج

**❌ سرور شروع نمی‌شود:**
```bash
node server.js  # ببینید چه خطایی میده
```

**❌ ایمیل ارسال نمی‌شود:**
- Gmail App Password درست باشد
- EMAIL_USER و EMAIL_FROM یکسان باشند

**❌ تلگرام کار نمی‌کند:**
- TELEGRAM_BOT_TOKEN درست باشد
- ربات را Start کرده باشید
- TELEGRAM_OWNER_CHAT_ID درست باشد

**❌ صفحه ۵۰۲ می‌دهد:**
```bash
pm2 status  # وضعیت اپ
pm2 restart payment-system
```

---

## 📞 پشتیبانی
- تلگرام: @Onicor
- کانال: @codmmd_ch  
- گروه: @codmmd_gp
