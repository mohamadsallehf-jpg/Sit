# 🔑 اطلاعات ورود پیش‌فرض

## 👑 پنل مالک (/owner)
- **نام کاربری:** `admin`
- **رمز عبور:** `Admin@1234`
- **آدرس:** `http://yourserver/owner`

## 👤 پنل ادمین (/admin)
- از طریق پنل مالک، ادمین جدید بسازید
- **آدرس:** `http://yourserver/admin`

---

## ⚠️ مهم - بعد از اولین ورود:
1. رمز عبور مالک را از پنل تنظیمات تغییر دهید
2. فایل `.env` بسازید و `JWT_SECRET` را تغییر دهید
3. ادمین‌های مورد نیاز را اضافه کنید

---

## 🚨 اگر قفل شدید یا رمز فراموش کردید:
```bash
node reset-owner.js
```
این دستور حساب مالک را با اطلاعات پیش‌فرض ریست می‌کند.

---

## 📝 تنظیم اطلاعات دلخواه:
فایل `.env` بسازید:
```
OWNER_USERNAME=admin
OWNER_PASSWORD=YourNewPassword123
JWT_SECRET=your_very_long_random_secret_key_here
```
سپس اجرا کنید:
```bash
node reset-owner.js
node server.js
```
