#!/bin/bash

# ============================================
#  اسکریپت نصب خودکار سیستم پرداخت
#  دامنه: panelvps.ir | IP: 82.115.17.235
# ============================================

set -e
echo "🚀 شروع نصب سیستم پرداخت..."

# ---- مرحله ۱: آپدیت و نصب پیش‌نیازها ----
echo "📦 نصب پیش‌نیازها..."
apt update && apt upgrade -y
apt install -y curl wget git build-essential unzip nginx certbot python3-certbot-nginx ufw

# نصب Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs
echo "✅ Node.js نصب شد: $(node --version)"

# نصب PM2
npm install -g pm2
echo "✅ PM2 نصب شد"

# ---- مرحله ۲: آپلود و Extract فایل‌ها ----
echo "📁 آماده‌سازی پوشه..."
mkdir -p /var/www/payment-system

# کپی zip از مسیر فعلی (فایل رو کنار این اسکریپت بذار)
if [ -f "payment-system-final.zip" ]; then
    cp payment-system-final.zip /var/www/
    cd /var/www
    unzip -o payment-system-final.zip
    cp -r payment-system/* /var/www/payment-system/
    echo "✅ فایل‌ها استخراج شدن"
else
    echo "❌ فایل payment-system-final.zip پیدا نشد!"
    echo "لطفاً فایل zip رو کنار این اسکریپت بذار و دوباره اجرا کن"
    exit 1
fi

cd /var/www/payment-system

# ---- مرحله ۳: ساخت فایل .env ----
echo "⚙️ ساخت فایل تنظیمات..."

# ساخت JWT Secret تصادفی
JWT_SECRET=$(openssl rand -base64 64 | tr -d '\n')
REFRESH_SECRET=$(openssl rand -base64 64 | tr -d '\n')
SESSION_SECRET=$(openssl rand -base64 32 | tr -d '\n')

cat > /var/www/payment-system/.env << EOF
# Server
PORT=3000
NODE_ENV=production
BASE_URL=https://panelvps.ir

# JWT
JWT_SECRET=${JWT_SECRET}
JWT_EXPIRES_IN=8h
REFRESH_TOKEN_SECRET=${REFRESH_SECRET}

# Owner - بعد از نصب حتماً عوض کن!
OWNER_USERNAME=admin
OWNER_PASSWORD=Admin@1388

# Database
DB_PATH=./db/database.sqlite

# Email
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_SECURE=false
EMAIL_USER=panelvpsvip@gmail.com
EMAIL_PASS=GMAIL_APP_PASSWORD_HERE
EMAIL_FROM_NAME=سیستم پرداخت
EMAIL_FROM=panelvpsvip@gmail.com

# Telegram - توکن جدید بعد از revoke اینجا بذار
TELEGRAM_BOT_TOKEN=TOKEN_HERE_AFTER_REVOKE
TELEGRAM_OWNER_CHAT_ID=CHAT_ID_HERE

# Payment Gateways (فعلاً خالی)
ZARINPAL_MERCHANT_ID=
ZARINPAL_SANDBOX=true
IDPAY_API_KEY=
VANDAR_API_KEY=

# Security
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX=100
UPLOAD_MAX_SIZE_MB=5
ALLOWED_ORIGINS=https://panelvps.ir

# Session
SESSION_SECRET=${SESSION_SECRET}
EOF

echo "✅ فایل .env ساخته شد"

# ---- مرحله ۴: نصب dependencies ----
echo "📦 نصب پکیج‌های Node..."
npm install --production
echo "✅ پکیج‌ها نصب شدن"

# ---- مرحله ۵: تنظیم Nginx ----
echo "🌐 تنظیم Nginx..."

cat > /etc/nginx/sites-available/payment-system << 'NGINX'
server {
    listen 80;
    server_name panelvps.ir www.panelvps.ir;

    # Redirect به HTTPS (بعد از SSL فعال میشه)
    # return 301 https://$host$request_uri;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 60s;
        client_max_body_size 10M;
    }
}
NGINX

# فعال‌سازی
ln -sf /etc/nginx/sites-available/payment-system /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

nginx -t && systemctl restart nginx && systemctl enable nginx
echo "✅ Nginx تنظیم شد"

# ---- مرحله ۶: فایروال ----
echo "🔥 تنظیم فایروال..."
ufw allow ssh
ufw allow 80/tcp
ufw allow 443/tcp
ufw --force enable
echo "✅ فایروال تنظیم شد"

# ---- مرحله ۷: راه‌اندازی با PM2 ----
echo "🚀 راه‌اندازی اپ..."
cd /var/www/payment-system
pm2 start ecosystem.config.js
pm2 startup systemd -u root --hp /root
pm2 save
echo "✅ PM2 راه‌اندازی شد"

# ---- مرحله ۸: SSL ----
echo ""
echo "=========================================="
echo "✅ نصب اولیه کامل شد!"
echo ""
echo "📌 مراحل بعدی که باید دستی انجام بدی:"
echo ""
echo "1️⃣  توکن تلگرام رو ریست کن (@BotFather → /revoke)"
echo "    بعد توکن جدید رو توی .env بذار:"
echo "    nano /var/www/payment-system/.env"
echo ""
echo "2️⃣  Gmail App Password بگیر و توی .env بذار"
echo "    (جای GMAIL_APP_PASSWORD_HERE)"
echo ""
echo "3️⃣  Chat ID تلگرام رو پیدا کن:"
echo "    ربات رو استارت کن، بعد این لینک رو باز کن:"
echo "    https://api.telegram.org/botTOKEN/getUpdates"
echo ""
echo "4️⃣  SSL رایگان نصب کن:"
echo "    certbot --nginx -d panelvps.ir -d www.panelvps.ir"
echo ""
echo "5️⃣  بعد از SSL، پسورد مالک رو عوض کن:"
echo "    (پیش‌فرض: admin / Admin@1388)"
echo ""
echo "🌐 سایت: http://panelvps.ir"
echo "👑 پنل مالک: http://panelvps.ir/owner"
echo "🔧 پنل ادمین: http://panelvps.ir/admin"
echo "=========================================="
